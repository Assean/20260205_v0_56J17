<?php session_start();?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FunTech 社群網站</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="js/jquery-3.7.1.min.js"></script>
</head>
<body>
<?php include_once "header.php";?>

<div id="main-content" class='container' style='min-height:700px'>
            <!-- Hero Section -->
            <section class="hero-section my-5">
                <div class="hero-overlay"></div>
                <div class="container hero-content">
                    <h1 class="hero-title">FunTech Community</h1>
                    <p class="hero-text">
                        探索科技與娛樂的無限可能。<br>
                        在這裡，每一個創意都值得被看見，每一位創客都能找到夥伴。
                    </p>
                    <a href="#join" class="btn btn-register btn-lg px-5 py-3 rounded-pill fs-4">立即加入我們</a>
                </div>
            </section>

            <!-- About Us Section -->
            <section id="about" class="my-5">
                <h2 class="section-title">關於我們</h2>
                <div class="row justify-content-center">
                    <div class="col-8">
                        <div class="about-card">
                            <p class="text-secondary">
                                FunTech 的故事源自熱愛科技與創新的社群。從最初的創業團隊到如今蓬勃發展的平台，
                                我們的使命是讓每一位成員都能在這裡找到屬於自己的創新舞台。
                                <br><br>
                                <strong class="text-primary">創新 · 合作 · 娛樂 · 科技</strong> 是我們的核心價值。
                            </p>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Features Section -->
            <section id="features" class="my-5">
                <h2 class="section-title">社群特色</h2>
                <div class="row">
                    <div class="col-4">
                        <div class="bg-info feature-card text-center border rounded">
                            <i class="fas fa-rocket feature-icon"></i>
                            <h3>創新成果展示</h3>
                            <p class="mt-3 text-secondary-light">
                                分享你的最新專案，獲得來自全球社群的回饋與支持。讓創意在此發光發熱。
                            </p>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="bg-info feature-card text-center border rounded">
                            <i class="fas fa-users feature-icon"></i>
                            <h3>互動與合作</h3>
                            <p class="mt-3 text-secondary-light">
                                尋找志同道合的夥伴，組建團隊，共同解決挑戰。連結是力量的泉源。
                            </p>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="bg-info feature-card text-center border rounded">
                            <i class="fas fa-gamepad feature-icon"></i>
                            <h3>遊戲化學習</h3>
                            <p class="mt-3 text-secondary-light">
                                透過我們的遊戲平台，在娛樂中學習最新的網頁技術與程式邏輯。
                            </p>
                        </div>
                    </div>
                </div>
            </section>
</div>


<div id="footer" class='text-center bg-primary text-white' style="height:45px;line-height:45px">Copyright © 2026 FunTech. All rights reserved.</div>

<script src="css/bootstrap.js"></script>
</body>
</html>