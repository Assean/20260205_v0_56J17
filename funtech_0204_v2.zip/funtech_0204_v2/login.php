<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FunTech 社群網站-登入</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <script src="js/jquery-3.7.1.min.js"></script>
</head>

<body>
    <?php include_once "header.php"; ?>

    <div id="main-content" class='container' style='min-height:700px'>
        <h2 class="text-center mt-5">會員登入</h2>
        <form action="api/check_account.php" method="post" class='w-50 mx-auto form-group'>
            <div class="my-3">
                <label for="account">帳號：</label>
                <input class="form-control" type="text" name="account" id="account">
            </div>
            <div class="my-3">
                <label for="password">密碼：</label>
                <input class="form-control" type="password" name="password" id="password">
            </div>

            <!-- div>input:submit+input:reset -->
            <div class='text-center my-4'>
                <input class="btn btn-primary" type="submit" value="登入">
                <input class="btn btn-warning" type="reset" value="重置">
            </div>

        </form>
    </div>


    <?php include_once "footer.php"; ?>
    <script src="css/bootstrap.js"></script>
</body>

</html>