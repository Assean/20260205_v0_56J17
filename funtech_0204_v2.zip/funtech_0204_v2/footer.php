
<div id="footer" class='text-center bg-primary text-white' style="height:45px;line-height:45px">Copyright © 2026 FunTech. All rights reserved.</div>
