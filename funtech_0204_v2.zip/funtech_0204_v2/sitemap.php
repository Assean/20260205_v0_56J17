<?php session_start();?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FunTech 社群網站</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="js/jquery-3.7.1.min.js"></script>
</head>
<body>
<?php include_once "header.php";?>

<div id="main-content" class='container' style='min-height:700px'>
    <h1 class="text-center my-4">網站地圖</h1>
</div>


<div id="footer" class='text-center bg-primary text-white' style="height:45px;line-height:45px">Copyright © 2026 FunTech. All rights reserved.</div>

<script src="css/bootstrap.js"></script>
</body>
</html>