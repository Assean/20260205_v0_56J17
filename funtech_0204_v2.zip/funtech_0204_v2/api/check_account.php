<?php
$dsn="mysql:host=localhost;charset=utf8;dbname=funtech";
$pdo=new PDO($dsn,'root','');

$sql="SELECT count(*) FROM `users` WHERE `account`='{$_POST['account']}' && `password`='{$_POST['password']}'";

$result=$pdo->query($sql)->fetchColumn();

if($result>0){
    session_start();
    $_SESSION['user']=$_POST['account'];
    header("location:../index.php");
}else{
    echo "<script>";
    echo "alert('你輸入的帳號密碼錯誤,請重新輸入');";
    echo "location.href='../login.php'";
    echo "</script>";
}



