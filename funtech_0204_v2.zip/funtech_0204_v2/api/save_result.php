<?php
$dsn="mysql:host=localhost;charset=utf8;dbname=funtech";
$pdo=new PDO($dsn,'root','');
$sql="insert into `result` (`game`,`status`,`time`,`account`) 
                     values('{$_POST['game']}','{$_POST['data']['result']}','{$_POST['data']['time']}','{$_POST['user']}')";
$pdo->exec($sql);